from fastapi.testclient import TestClient
from app.main import app


def test_frontend_is_served():
    client = TestClient(app)
    response = client.get('/app')
    assert response.status_code == 200
    assert 'text/html' in response.headers['content-type']
    assert 'AutoFix Pro' in response.text
    assert '/api/ordenes' in response.text
